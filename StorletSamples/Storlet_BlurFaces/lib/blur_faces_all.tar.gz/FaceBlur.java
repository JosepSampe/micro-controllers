import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
 
public class FaceBlur {
    private static int MAX_RECTANGLES = 100;
    public static void main(String[] args) throws IOException {

        int blurring_level = Integer.parseInt(args[0]);

        // OpenCV initialization 
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
 
        BufferedReader br = new BufferedReader(new FileReader("/tmp/input/metadata"));
        String line = br.readLine();

        int numRectangles = Integer.parseInt(line);
        
        // Load image        
        Mat image = Highgui.imread("/tmp/input/object.jpg");

        // for each rectangle, perform blurring       
        for (int i=0; i<numRectangles; i++) {
                line = br.readLine();
                String[] tokens = line.split(" ");
                Rect rect = new Rect(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]), Integer.parseInt(tokens[3]));
        	Mat submat = image.submat(rect);
        	Mat blurred = new Mat();
        	Imgproc.blur(submat, blurred, new Size(blurring_level,blurring_level));
        	blurred.copyTo(image.submat(rect));
        }
 
        String filename = "/tmp/output/output.jpg";
        Highgui.imwrite(filename, image);
    }
}
