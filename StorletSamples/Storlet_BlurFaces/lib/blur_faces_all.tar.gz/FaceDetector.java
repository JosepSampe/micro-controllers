import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
 
public class FaceDetector {
    private static int MAX_RECTANGLES = 100;
    public static void main(String[] args) {

        int blurring_level = Integer.parseInt(args[0]);

        // OpenCV initialization 
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
 
        Rect allRectangles[] = new Rect[MAX_RECTANGLES];
        int numRectangles = 0;
        
        // Load image        
        Mat image = Highgui.imread("/tmp/input/object.jpg");

        String[] classifierFiles = {"/tmp/forgetit/blurfaces/haarcascade_frontalface_alt2.xml",
        		"/tmp/forgetit/blurfaces/haarcascade_frontalface_alt_tree.xml",
        		"/tmp/forgetit/blurfaces/haarcascade_frontalface_alt.xml",
        		"/tmp/forgetit/blurfaces/haarcascade_frontalface_default.xml",
        		"/tmp/forgetit/blurfaces/haarcascade_profileface.xml"};
        
        // traverse all classifier files
        for (int q=0; q<classifierFiles.length; q++) {     
	        CascadeClassifier faceDetector =
	        		new CascadeClassifier(classifierFiles[q]);
	        
	        MatOfRect faceDetections = new MatOfRect();
	        faceDetector.detectMultiScale(image, faceDetections);
	 
	        
	        Rect[] rectanglesDetected = faceDetections.toArray();
	        int numDetected = rectanglesDetected.length;

	        // add newly discovered faces to rectangle array
	        for (int i=0; i<numDetected; i++) {
	        	allRectangles[numRectangles++] = rectanglesDetected[i];
	        }
        }
 
        // for each rectangle, perform blurring       
        for (int i=0; i<numRectangles; i++) {
        	Mat submat = image.submat(allRectangles[i]);
        	Mat blurred = new Mat();
        	Imgproc.blur(submat, blurred, new Size(blurring_level,blurring_level));
        	blurred.copyTo(image.submat(allRectangles[i]));
        }
 
        String filename = "/tmp/output/output.jpg";
        Highgui.imwrite(filename, image);
    }
}
