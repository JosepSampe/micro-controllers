#!/bin/sh

cd /tmp/forgetit/blurfaces

java -cp .:opencv-247.jar -Djava.library.path=/tmp/forgetit/blurfaces FaceBlur $1
